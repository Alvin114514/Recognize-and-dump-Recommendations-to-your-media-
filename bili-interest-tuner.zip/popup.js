/* =========================================================
 * popup.js —— B站兴趣调谐器
 * 处理流程（全部透明展示在面板中）：
 *   Step 1. 从 chrome.history 读取最近 N 条历史标题 + URL
 *   Step 2. 使用 Intl.Segmenter（浏览器原生）做中文分词
 *   Step 3. 停用词 + 无意义词过滤（词典 + 正则）
 *   Step 4. 词频哈希统计 + 降序
 *   Step 5. 基于"兴趣领域词典"对命中关键词加权打分
 * 所有勾选结果统一写入 chrome.storage.local
 * ========================================================= */

const PIPELINE = [
  document.getElementById('pipe-1-desc'),
  document.getElementById('pipe-2-desc'),
  document.getElementById('pipe-3-desc'),
  document.getElementById('pipe-4-desc'),
  document.getElementById('pipe-5-desc'),
];
function setStep(idx, text, ok = true) {
  const el = PIPELINE[idx - 1];
  el.textContent = text;
  el.parentElement.parentElement.classList.toggle('ok', ok);
  el.parentElement.parentElement.classList.toggle('active', ok);
}

/* ---------- 停用词 & 过滤词典 ---------- */
const STOPWORDS = new Set([
  '的','了','和','是','就','都','而','及','与','这','那','你','我','他','她','它','们','在','也','被','让','把','被','或','但','不','没','有','还','又','只','会','能','可以','一个','一些','一下','什么','怎么','为什么','如何','这个','那个','我们','你们','他们','自己','因为','所以','如果','虽然','但是','就是','还是','已经','以及','之后','之前','关于','通过','进行','成为','对于','其中','不过','而且','并且','由于','然后','这样','那样','一种','一次','这些','那些','其实','非常','比较','可能','应该','需要','一起','两个','现在','今天','昨天','明天','最近','使用','例如','很多','一些','一样','一般','其中','一下','一种','一直','其实','大家','出来','里面','上面','下面','时候','东西','事情','部分','过程','结果','方式','方法','内容','相关','情况','信息','系统','功能','问题','工作','时间','页面','网站','地址','搜索','首页','在线','视频','播放','下载','登录','注册','中心','官方','中文','英文','简体','繁体','doc','docx','pdf','txt','html','php','jsp','com','net','cn','org','io','www','http','https','new','tab','blank','page','search','result','index','home'
]);

/* 域名片段（URL 的 host 中常出现，过滤掉） */
const DOMAIN_CHUNKS = new Set([
  'bilibili','baidu','google','zhihu','weibo','taobao','jd','douyin','kuaishou','xiaohongshu','csdn','github','gitee','google','bing','sogou','youku','iqiyi','qq','aliyun','cloud','wikipedia','youtube','twitter','x','facebook','instagram','pornhub','xvideos','jav','b23','tv'
]);

/* 兴趣领域 → 关键词词典（打分用） */
const INTEREST_DICT = {
  '🎮 游戏': ['游戏','我的世界','mc','minecraft','原神','王者','荣耀','英雄联盟','lol','steam','ksp','坎巴拉','mod','模组','整合包','机械动力','create','kubejs','红石','生存','创造','pvp','pve','dota','csgo','cs2','永劫','apex','吃鸡','fps','单机','联机','主播','实况','攻略','剧情','关卡','boss','像素','沙盒','建造','工厂','异星','戴森','环世界','rimworld','缺氧','饥荒'],
  '🛠️ 编程 / 开发': ['编程','代码','开发','算法','python','javascript','java','c++','c语言','cpp','rust','typescript','ts','js','前端','后端','api','debug','bug','框架','react','vue','electron','vite','node','npm','pnpm','docker','服务器','部署','github','git','数据库','mysql','sql','人工智能','ai','llm','机器学习','深度学习','神经网络','大模型','kubejs','modding'],
  '📚 学习 / 考试': ['学习','课程','教程','考试','复习','托福','雅思','四级','六级','考研','中考','高考','刷题','网课','公开课','b站大学','知识','大学','高中','初中','物理','化学','数学','语文','英语','生物','历史','地理','政治','作业','答案','解析'],
  '🎬 影视 / 动漫': ['动漫','动画','番剧','电影','电视剧','综艺','解说','剪辑','预告片','pv','op','ed','国漫','日漫','漫威','dc','哈利波特','三体','小说','原著','二创','同人','鬼畜','amv','mad'],
  '🎵 音乐': ['音乐','歌曲','mv','单曲','专辑','演唱会','现场版','cover','翻唱','remix','纯音乐','bgm','op','ed','ost','钢琴','吉他','说唱','rap','摇滚','古典','电子','kpop','jpop','古风'],
  '🍚 生活 / 美食 / Vlog': ['美食','做饭','菜谱','探店','vlog','日常','旅行','旅游','户外','露营','开箱','评测','测评','健身','减肥','穿搭','化妆','护肤','宠物','猫','狗','生活记录'],
  '🧪 科技 / 数码 / 硬件': ['数码','手机','电脑','笔记本','显卡','cpu','主板','内存','硬盘','装机','外设','键盘','鼠标','耳机','相机','镜头','无人机','平板','ipad','apple','苹果','安卓','鸿蒙','windows','linux','芯片','半导体','ai','人工智能','机器人','特斯拉','自动驾驶'],
  '🏫 校园 / 教育': ['学校','大学','中学','小学','老师','同学','校园','宿舍','寝室','班级','毕业','论文','答辩','导师','保研','留学','申请','offer','奖学金','社团','军训','开学'],
  '💰 经济 / 商业': ['股票','基金','投资','理财','经济','金融','市场','创业','商业','公司','行业','产品','运营','营销','老板','副业','赚钱','工资','薪酬','职场','面试','简历'],
  '⚽ 体育': ['足球','篮球','nba','cba','世界杯','欧冠','英超','西甲','中超','梅西','c罗','詹姆斯','库里','羽毛球','乒乓球','游泳','跑步','健身','举重','奥运','比赛','赛事'],
};

/* ---------- 全局运行数据 ---------- */
let state = {
  historyCount: 0,
  totalRawTokens: 0,
  totalValidTokens: 0,
  freqList: [],         // [{word, count}]
  interestScores: {},   // {领域: score}
  selectedLikes: new Set(),
  selectedDislikes: new Set(),
  selectedInterests: new Set(),
};

/* ---------- 存档 / 恢复 ---------- */
function saveState() {
  const snapshot = {
    historyCount: state.historyCount,
    totalRawTokens: state.totalRawTokens,
    totalValidTokens: state.totalValidTokens,
    freqList: state.freqList,
    interestScores: state.interestScores,
    selectedLikes: [...state.selectedLikes],
    selectedDislikes: [...state.selectedDislikes],
    selectedInterests: [...state.selectedInterests],
    pipelineTexts: PIPELINE.map(el => el.textContent),
    savedAt: Date.now(),
  };
  try { chrome.storage.local.set({ biliInterestSnapshot: snapshot }, () => {}); } catch (_) {}
}
function restoreState(snapshot) {
  if (!snapshot) return false;
  state.historyCount = snapshot.historyCount || 0;
  state.totalRawTokens = snapshot.totalRawTokens || 0;
  state.totalValidTokens = snapshot.totalValidTokens || 0;
  state.freqList = snapshot.freqList || [];
  state.interestScores = snapshot.interestScores || {};
  state.selectedLikes = new Set(snapshot.selectedLikes || []);
  state.selectedDislikes = new Set(snapshot.selectedDislikes || []);
  state.selectedInterests = new Set(snapshot.selectedInterests || []);
  if (snapshot.pipelineTexts) {
    snapshot.pipelineTexts.forEach((txt, i) => {
      if (txt && PIPELINE[i]) {
        PIPELINE[i].textContent = txt;
        const stepEl = PIPELINE[i].parentElement.parentElement;
        stepEl.classList.add('ok', 'active');
      }
    });
  }
  return true;
}

/* ---------- Step 1. 读取历史 ---------- */
async function step1_loadHistory(daysBack = 90, max = 10000) {
  const end = Date.now();
  const start = end - daysBack * 24 * 3600 * 1000;
  const items = await new Promise((res, rej) => {
    try { chrome.history.search({ text: '', startTime: start, endTime: end, maxResults: max }, (r) => res(r || [])); }
    catch (e) { rej(e); }
  });
  /* 只用标题做分词 —— URL 原文不含自然语言，送进分词器只会切出链接碎片 */
  const titles = items.map(i => i.title || '').filter(Boolean);
  const skipped = items.length - titles.length;
  state.historyCount = items.length;
  setStep(1, `✅ 读取到 ${items.length} 条浏览记录（跨度 ${daysBack} 天），其中 ${titles.length} 条有标题可用于分词${skipped ? `，${skipped} 条无标题已跳过` : ''}`);
  return titles.join('  ');
}

/* ---------- Step 2. 中文分词 ---------- */
function step2_tokenize(text) {
  const tokens = [];
  try {
    const seg = new Intl.Segmenter(['zh-CN', 'en'], { granularity: 'word' });
    for (const s of seg.segment(text)) {
      if (s.isWordLike) tokens.push(s.segment);
    }
  } catch (e) {
    /* Intl 不可用时的降级：按标点切英文，按 char 组中文 */
    const fallback = text.split(/[\s\-_./\\?#=&%@!，。？！《》「」（）()【】、：；，·~`|^+\[\]{}"'<>…—]+/);
    tokens.push(...fallback.filter(Boolean));
  }
  state.totalRawTokens = tokens.length;
  setStep(2, `✅ 共切分出 ${tokens.length} 个原始词（已用浏览器原生 Intl.Segmenter 中文分词）`);
  return tokens;
}

/* ---------- Step 3. 过滤无意义 / 停用词 ---------- */
function isMeaningless(w) {
  if (!w) return true;
  const x = w.trim().toLowerCase();
  if (x.length < 2) return true;                                      // 单字排除
  if (/^[\d.]+$/.test(x)) return true;                                // 纯数字
  if (/^[a-z0-9]{16,}$/.test(x) && !/[a-z]/.test(x)) return true;     // 纯长 ID
  if (STOPWORDS.has(x)) return true;                                  // 停用词
  if (DOMAIN_CHUNKS.has(x)) return true;                              // 域名片段
  if (/\.(png|jpg|jpeg|gif|webp|svg|woff|woff2|ttf|mp4|mp3|wav)$/.test(x)) return true; // 文件后缀
  if (/^(?:[0-9a-f]{6,}|uuid[0-9a-f-]+)$/.test(x)) return true;      // hash/uuid
  if (/%[0-9a-f]{2}/.test(x)) return true;                           // URL 编码串
  return false;
}
function step3_filter(rawTokens) {
  const out = [];
  const removedExamples = [];
  for (const t of rawTokens) {
    const w = t.trim().toLowerCase();
    if (isMeaningless(w)) {
      if (removedExamples.length < 8) removedExamples.push(t || '(空)');
      continue;
    }
    out.push(w);
  }
  state.totalValidTokens = out.length;
  const dropRate = state.totalRawTokens ? ((1 - state.totalValidTokens / state.totalRawTokens) * 100).toFixed(1) : '0';
  setStep(3, `✅ 过滤后剩 ${out.length} 个有效词（丢弃率 ${dropRate}%，示例被过滤：${removedExamples.join('、') || '无'}）`);
  return out;
}

/* ---------- Step 4. 词频统计 + 排序 ---------- */
function step4_count(validTokens, topN = 80) {
  const freq = new Map();
  for (const t of validTokens) freq.set(t, (freq.get(t) || 0) + 1);
  const arr = [...freq.entries()]
    .map(([word, count]) => ({ word, count }))
    .sort((a, b) => b.count - a.count || a.word.localeCompare(b.word))
    .slice(0, topN);
  state.freqList = arr;
  setStep(4, `✅ 共 ${freq.size} 个唯一有效词，已按出现次数降序取前 ${arr.length}，最高：${arr[0]?.word}（${arr[0]?.count} 次）`);
  return arr;
}

/* ---------- Step 5. 兴趣画像打分 ---------- */
function step5_interest(freqMapAsObject) {
  const scores = {};
  for (const domain of Object.keys(INTEREST_DICT)) {
    let s = 0;
    for (const kw of INTEREST_DICT[domain]) {
      const hit = freqMapAsObject[kw.toLowerCase()];
      if (hit) s += hit * (kw.length >= 4 ? 1.4 : 1);
    }
    scores[domain] = s;
  }
  const sorted = Object.entries(scores)
    .sort((a, b) => b[1] - a[1])
    .filter(([, s]) => s > 0);
  state.interestScores = Object.fromEntries(sorted);
  const top3 = sorted.slice(0, 3).map(([k, s]) => `${k}=${s.toFixed(0)}`).join('，') || '（暂无明显倾向）';
  setStep(5, `✅ 命中 ${sorted.length} 个兴趣领域，Top 3：${top3}`);
  return sorted;
}

/* ---------- UI 渲染 ---------- */
function renderFreq() {
  const wrap = document.getElementById('freq-list');
  wrap.innerHTML = '';
  if (!state.freqList.length) {
    wrap.innerHTML = '<div class="empty">还没生成数据，先点上方「🔍 分析我的浏览历史」</div>';
    return;
  }
  const max = state.freqList[0].count;
  state.freqList.forEach(({ word, count }, idx) => {
    const percent = max ? Math.max(4, (count / max) * 100) : 0;
    const row = document.createElement('label');
    row.className = 'freq-row';
    const checked = state.selectedLikes.has(word) ? 'checked' : '';
    row.innerHTML = `
      <input type="checkbox" data-kind="like" data-word="${encodeURIComponent(word)}" ${checked}/>
      <span class="rank">${idx + 1}</span>
      <span class="word">${escapeHtml(word)}</span>
      <div class="bar"><div class="bar-inner" style="width:${percent}%"></div></div>
      <span class="count">${count} 次</span>
    `;
    wrap.appendChild(row);
  });
  document.getElementById('total-words').textContent = `前 ${state.freqList.length} / ${state.totalValidTokens} 词`;
  document.getElementById('card-freq').hidden = false;
}

function renderInterest(scoresArr) {
  const wrap = document.getElementById('interest-list');
  wrap.innerHTML = '';
  if (!scoresArr || !scoresArr.length) {
    wrap.innerHTML = '<div class="empty">暂无足够数据生成兴趣画像。（可以直接去下方"✍️ 自定义补充"手动加）</div>';
    document.getElementById('card-interest').hidden = false;
    return;
  }
  const max = scoresArr[0][1] || 1;
  scoresArr.forEach(([name, score]) => {
    const w = Math.max(6, (score / max) * 100);
    const row = document.createElement('label');
    row.className = 'interest-row';
    const checked = state.selectedInterests.has(name) ? 'checked' : '';
    row.innerHTML = `
      <input type="checkbox" data-kind="interest" data-word="${encodeURIComponent(name)}" ${checked}/>
      <span class="interest-name">${name}</span>
      <div class="bar"><div class="bar-inner interest-bar" style="width:${w}%"></div></div>
      <span class="score">${score.toFixed(0)} 分</span>
    `;
    wrap.appendChild(row);
  });
  document.getElementById('card-interest').hidden = false;
}

function renderTags() {
  const likes = [...state.selectedLikes];
  const dislikes = [...state.selectedDislikes];
  const interests = [...state.selectedInterests];
  document.getElementById('tag-likes').innerHTML = likes.length
    ? likes.map(w => `<span class="tag like" data-kind="like" data-word="${encodeURIComponent(w)}">${escapeHtml(w)}<button class="tag-x">×</button></span>`).join('')
    : '<span class="tag-empty">暂无</span>';
  document.getElementById('tag-dislikes').innerHTML = dislikes.length
    ? dislikes.map(w => `<span class="tag dislike" data-kind="dislike" data-word="${encodeURIComponent(w)}">${escapeHtml(w)}<button class="tag-x">×</button></span>`).join('')
    : '<span class="tag-empty">暂无</span>';
  document.getElementById('tag-interests').innerHTML = interests.length
    ? interests.map(w => `<span class="tag interest" data-kind="interest" data-word="${encodeURIComponent(w)}">${escapeHtml(w)}<button class="tag-x">×</button></span>`).join('')
    : '<span class="tag-empty">暂无</span>';
  document.getElementById('card-selected').hidden = !(likes.length || dislikes.length || interests.length);
  const btn = document.getElementById('btn-apply');
  btn.disabled = !(likes.length || dislikes.length || interests.length);
  saveState(); /* 每次标签变化都自动存档 */
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ---------- 统一事件 ---------- */
document.getElementById('btn-analyze').addEventListener('click', async () => {
  const btn = document.getElementById('btn-analyze');
  btn.disabled = true;
  try {
    [1,2,3,4,5].forEach(i => setStep(i, '⏳ 进行中…', false));
    const text = await step1_loadHistory();
    const raw = step2_tokenize(text);
    const valid = step3_filter(raw);
    const freqList = step4_count(valid);
    const asObj = {}; freqList.forEach(x => asObj[x.word] = x.count);
    const interestArr = step5_interest(asObj);
    /* 不再自动勾选 —— 用户自己勾选后点"保存"按钮才生效 */
    renderFreq();
    renderInterest(interestArr);
    document.getElementById('card-save-selection').hidden = false;
    saveState(); /* 自动存档 */
  } catch (e) {
    alert('读取浏览器历史失败：' + e.message + '\n请在扩展管理中确认已授予「读取浏览历史」权限。');
    console.error(e);
  } finally {
    btn.disabled = false;
  }
});

/* 词频 + 兴趣 的勾选框（只更新内存 Set，不立即刷新下方标签栏，等点"保存"按钮） */
document.addEventListener('change', (e) => {
  const t = e.target;
  if (!(t instanceof HTMLInputElement)) return;
  const kind = t.dataset.kind;
  if (!kind) return;
  const word = decodeURIComponent(t.dataset.word);
  const setRef = kind === 'dislike' ? state.selectedDislikes
    : kind === 'interest' ? state.selectedInterests : state.selectedLikes;
  if (t.checked) setRef.add(word); else setRef.delete(word);
  /* 不调 renderTags —— 等用户点"保存"按钮 */
});

/* 全选/全不选 关键词（只更新勾选状态，不立即刷新下方标签栏） */
document.getElementById('toggle-all-keywords').addEventListener('change', (e) => {
  const toCheck = e.target.checked;
  document.querySelectorAll('#freq-list input[type=checkbox][data-kind="like"]').forEach(cb => {
    cb.checked = toCheck;
    const w = decodeURIComponent(cb.dataset.word);
    if (toCheck) state.selectedLikes.add(w); else state.selectedLikes.delete(w);
  });
});

/* 💾 保存勾选按钮：把上方勾选的关键词/兴趣写入下方标签栏 + 存档 */
document.getElementById('btn-save-selection').addEventListener('click', () => {
  renderTags();
  const btn = document.getElementById('btn-save-selection');
  const original = btn.textContent;
  btn.textContent = '✅ 已保存到下方';
  btn.disabled = true;
  setTimeout(() => { btn.textContent = original; btn.disabled = false; }, 1500);
});

/* 添加自定义关键词 */
function takeInput(id) {
  const el = document.getElementById(id);
  const v = (el.value || '').trim();
  el.value = '';
  return v;
}
document.getElementById('btn-add-keyword').addEventListener('click', () => {
  const v = takeInput('custom-keyword');
  if (!v) return;
  v.split(/[\s,，、;；]+/).filter(Boolean).forEach(k => state.selectedLikes.add(k));
  renderTags();
});
document.getElementById('btn-add-block').addEventListener('click', () => {
  const v = takeInput('custom-block');
  if (!v) return;
  v.split(/[\s,，、;；]+/).filter(Boolean).forEach(k => state.selectedDislikes.add(k));
  renderTags();
});

/* 标签删除 */
document.addEventListener('click', (e) => {
  if (!(e.target instanceof HTMLElement)) return;
  if (!e.target.classList.contains('tag-x')) return;
  const tag = e.target.parentElement;
  const kind = tag.dataset.kind;
  const word = decodeURIComponent(tag.dataset.word);
  const setRef = kind === 'dislike' ? state.selectedDislikes
    : kind === 'interest' ? state.selectedInterests : state.selectedLikes;
  setRef.delete(word);
  /* 同步取消勾选框 */
  const selector = `input[data-kind="${kind}"][data-word="${encodeURIComponent(word)}"]`;
  const cb = document.querySelector(selector);
  if (cb) cb.checked = false;
  renderTags();
});

/* 一键应用：存档配置（不自动打开 B 站，用户自己浏览时 content.js 自动生效） */
document.getElementById('btn-apply').addEventListener('click', async () => {
  const payload = {
    likes: [...state.selectedLikes],
    dislikes: [...state.selectedDislikes],
    interests: [...state.selectedInterests],
    updatedAt: Date.now(),
  };
  await new Promise(r => chrome.storage.local.set({ biliInterest: payload }, r));
  saveState();
  /* 不再自动打开 B 站标签页，只提示已保存 */
  const btn = document.getElementById('btn-apply');
  const original = btn.textContent;
  btn.textContent = '✅ 已保存！下次浏览 B 站时自动生效';
  btn.disabled = true;
  setTimeout(() => { btn.textContent = original; btn.disabled = false; }, 2500);
});

/* 启动时恢复上次的完整存档（词频列表 + 兴趣画像 + 勾选状态 + 流水线文字） */
chrome.storage.local.get(['biliInterestSnapshot', 'biliInterest'], (res) => {
  const snap = res?.biliInterestSnapshot;
  if (snap && restoreState(snap)) {
    /* 恢复词频列表 UI */
    if (state.freqList.length) renderFreq();
    /* 恢复兴趣画像 UI */
    const scoresArr = Object.entries(state.interestScores).sort((a,b) => b[1]-a[1]);
    if (scoresArr.length) renderInterest(scoresArr);
    /* 恢复已选标签 */
    renderTags();
  } else if (res?.biliInterest) {
    /* 兼容旧版只有 biliInterest 没有快照的情况 */
    const p = res.biliInterest;
    (p.likes || []).forEach(x => state.selectedLikes.add(x));
    (p.dislikes || []).forEach(x => state.selectedDislikes.add(x));
    (p.interests || []).forEach(x => state.selectedInterests.add(x));
    renderTags();
  }
});
