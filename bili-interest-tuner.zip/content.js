/* =========================================================
 * content.js —— 注入到所有 bilibili.com 页面
 * 作用：
 *   1) 读取 chrome.storage.local.biliInterest（用户在 popup 勾选的 likes/dislikes/interests）
 *   2) 首页/分区页：对每个推荐视频卡片做三件事：
 *        · 标题/UP主/标签命中 dislike 关键词 → 整体隐藏（加 data-bit-hidden 属性）
 *        · 命中 like 关键词 → 绿色边框 + 置顶（加 data-bit-like 属性）
 *        · 命中兴趣领域关键词 → 浅粉边框（加 data-bit-interest 属性）
 *   3) 若是"刚从 popup 点了一键应用跳转过来的首页"：自动模拟 3 次高优关键词搜索，
 *      让 B 站的"近期搜索"记住你的倾向，从而影响推荐算法。
 *   4) MutationObserver 监听无限滚动新增的卡片。
 *   5) 视频详情页：如果 dislike 命中当前视频 UP 主或标题 → 点"不感兴趣"按钮。
 * ========================================================= */

let cfg = { likes: [], dislikes: [], interests: [], updatedAt: 0 };
const HIT_CACHE = new WeakMap();  /* Element → {like:[], dislike:[], interest:[]} */

/* ---------- 加载配置 ---------- */
function loadCfg(cb) {
  try {
    chrome.storage.local.get('biliInterest', (res) => {
      if (res?.biliInterest) cfg = { ...cfg, ...res.biliInterest };
      if (cb) cb();
    });
  } catch (e) { /* storage API 在某些 iframe 场景下失败，忽略 */ }
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.biliInterest) {
    cfg = { ...cfg, ...changes.biliInterest.newValue };
    rerunAll();
  }
});

/* ---------- 匹配器 ---------- */
function textMatchesAny(text, keywords) {
  if (!text) return [];
  const t = text.toLowerCase();
  return keywords.filter(k => t.includes(String(k).toLowerCase()));
}
function classify(el) {
  if (HIT_CACHE.has(el)) return HIT_CACHE.get(el);
  const titleEl = el.querySelector('a[title], h3, .title, .bili-video-card__info--tit, .info .title, .card-pc .title');
  const upEl = el.querySelector('.up-name, .bili-video-card__info--author, .name, .user-name, .bili-video-card__info--right a');
  const tagEls = el.querySelectorAll('.bili-video-card__info--bottom, .tag, .tags, .bottom-tag, .sub-title');
  const textPieces = [titleEl?.textContent || '', upEl?.textContent || '', ...[...tagEls].map(e => e.textContent || '')];
  const allText = textPieces.join(' | ');
  const result = {
    like: textMatchesAny(allText, cfg.likes),
    dislike: textMatchesAny(allText, cfg.dislikes),
    interest: textMatchesAny(allText, cfg.interests),
  };
  HIT_CACHE.set(el, result);
  return result;
}

/* 找到当前 DOM 中所有"视频推荐卡片"的候选容器 —— B 站 DOM 多变，用多选择器覆盖 */
const CARD_SELECTORS = [
  'div.bili-video-card',                /* 新版首页大卡片 */
  'li.video-list-item',                 /* 分区列表 */
  'a.feed-card',                        /* 首页老卡片 */
  'div.video-card-recommended',         /* 视频详情页右侧推荐 */
  'div.card-box',                       /* 活动卡片 */
  'div.feed-roll-card',                 /* 动态卡片 */
  'div.rank-wrap li',                   /* 排行榜 */
];
const CARD_SEL = CARD_SELECTORS.join(',');

function processCard(card) {
  if (!card || card.dataset.bitProcessed === '1') return;
  const r = classify(card);
  card.dataset.bitProcessed = '1';
  card.removeAttribute('data-bit-hidden');
  card.removeAttribute('data-bit-like');
  card.removeAttribute('data-bit-interest');
  card.classList.remove('bit-hidden','bit-like','bit-interest');
  if (r.dislike.length) {
    card.setAttribute('data-bit-hidden', r.dislike.join('|'));
    card.classList.add('bit-hidden');
  } else if (r.like.length) {
    card.setAttribute('data-bit-like', r.like.join('|'));
    card.classList.add('bit-like');
    /* 把命中的卡片放到父节点最前面 → 等于"加权展示" */
    const parent = card.parentElement;
    if (parent && parent.firstElementChild !== card && !parent.dataset.bitSorted) {
      try { parent.prepend(card); } catch (_) {}
    }
  } else if (r.interest.length) {
    card.setAttribute('data-bit-interest', r.interest.join('|'));
    card.classList.add('bit-interest');
  }
  /* 对容器加一个 flag，避免每次都 prepend 乱序 */
  card.parentElement && (card.parentElement.dataset.bitSorted = '1');
}

/* ---------- 详情页：dislike 则点"不感兴趣" ---------- */
function handleDetailPage() {
  if (!/\/video\/(BV|av)\w+/.test(location.pathname)) return;
  if (!cfg.dislikes.length) return;
  const title = (document.querySelector('h1')?.textContent || '') + ' | ' +
                (document.querySelector('.up-name,.a-pan-name')?.textContent || '');
  const hit = textMatchesAny(title, cfg.dislikes);
  if (!hit.length) return;
  /* 尝试找到"不感兴趣"按钮（B 站右侧推荐卡片右下角更多菜单里） */
  const tryClickDislike = () => {
    const btns = document.querySelectorAll('button, .dislike, [aria-label="不感兴趣"], .bpx-player-dm-more');
    for (const b of btns) {
      if ((b.textContent || b.getAttribute('aria-label') || '').includes('不感兴趣')) {
        b.click(); return true;
      }
    }
    return false;
  };
  /* 延迟两次，等右侧推荐 DOM 生成 */
  setTimeout(tryClickDislike, 2000);
  setTimeout(tryClickDislike, 5000);
}

/* ---------- 全量重算 ---------- */
function rerunAll() {
  document.querySelectorAll(CARD_SEL).forEach(processCard);
  handleDetailPage();
}

/* ---------- 静默投喂算法（加强 10 倍，完全不打开可见页面） ---------- */
async function silentFeed() {
  try {
    const key = 'bitFeed_' + (cfg.updatedAt || '0');
    if (!cfg.updatedAt || sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, '1');

    const likes = [...cfg.likes].slice(0, 10).filter(Boolean);   /* Top 10（原来 3） */
    const dislikes = [...cfg.dislikes].slice(0, 5).filter(Boolean);

    /* 每个 like 关键词发 3 种请求 = 10×3=30 次（原来 3×1=3 次 → 加强 10 倍） */
    for (const kw of likes) {
      const enc = encodeURIComponent(kw);
      /* ① 搜索页面请求（B 站后端记录搜索历史） */
      fetch(`https://search.bilibili.com/all?keyword=${enc}`, { credentials: 'include', mode: 'no-cors' }).catch(()=>{});
      /* ② 搜索 API 请求（触发推荐系统关联） */
      fetch(`https://api.bilibili.com/x/web-interface/search/all/v2?keyword=${enc}`, { credentials: 'include', mode: 'no-cors' }).catch(()=>{});
      /* ③ 搜索建议请求（强化搜索记录） */
      fetch(`https://s.search.bilibili.com/main/suggest?term=${enc}`, { credentials: 'include', mode: 'no-cors' }).catch(()=>{});
      await new Promise(r => setTimeout(r, 300));
    }

    /* dislike 关键词：搜索但不点击 → 告诉算法"你对这类内容不感兴趣" */
    for (const kw of dislikes) {
      const enc = encodeURIComponent(kw);
      fetch(`https://search.bilibili.com/all?keyword=${enc}`, { credentials: 'include', mode: 'no-cors' }).catch(()=>{});
      fetch(`https://api.bilibili.com/x/web-interface/search/all/v2?keyword=${enc}`, { credentials: 'include', mode: 'no-cors' }).catch(()=>{});
      await new Promise(r => setTimeout(r, 200));
    }
  } catch (e) { /* 静默 */ }
}

/* ---------- 启动 & MutationObserver ---------- */
function start() {
  loadCfg(() => {
    rerunAll();
    silentFeed();   /* 静默投喂，不打开任何可见页面 */
  });
  const mo = new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.addedNodes && m.addedNodes.length) {
        m.addedNodes.forEach(n => {
          if (n.nodeType !== 1) return;
          if (n.matches && n.matches(CARD_SEL)) processCard(n);
          n.querySelectorAll && n.querySelectorAll(CARD_SEL).forEach(processCard);
        });
      }
    }
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', start, { once: true });
} else {
  start();
}
