/* background.js —— MV3 service worker
 * 任务：
 *  1) 接收 popup 发来的 APPLY_TO_BILI 消息后，把已勾选配置落地到 storage（其实 popup 自己已存），
 *     然后打开/激活 bilibili.com 首页标签页，让 content.js 接手做推荐调整。
 *  2) 提供极简的"查询配置"和"清空配置"接口，便于调试。
 */

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get('biliInterest', (res) => {
    if (!res?.biliInterest) {
      chrome.storage.local.set({ biliInterest: { likes: [], dislikes: [], interests: [], updatedAt: 0 } });
    }
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  /* APPLY_TO_BILI 已废弃：popup 直接写 storage，用户自己浏览 B 站时 content.js 自动读取生效 */
  if (msg.type === 'GET_CONFIG') {
    chrome.storage.local.get('biliInterest', (r) => sendResponse(r?.biliInterest || null));
    return true;
  }
  if (msg.type === 'CLEAR_CONFIG') {
    chrome.storage.local.remove(['biliInterest', 'biliInterestSnapshot'], () => sendResponse({ ok: true }));
    return true;
  }
  return false;
});
